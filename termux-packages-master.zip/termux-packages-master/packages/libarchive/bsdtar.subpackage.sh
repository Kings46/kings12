TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/"
TERMUX_SUBPKG_DESCRIPTION="The tar(1) and cpio(1) programs from FreeBSD, using libarchive"
