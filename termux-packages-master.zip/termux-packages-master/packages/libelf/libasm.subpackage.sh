TERMUX_SUBPKG_INCLUDE="lib/libasm*.so* include/elfutils/libasm.h"
TERMUX_SUBPKG_DESCRIPTION="Library to assemble and disassemble instructions"
TERMUX_SUBPKG_DEPENDS="libdw"
