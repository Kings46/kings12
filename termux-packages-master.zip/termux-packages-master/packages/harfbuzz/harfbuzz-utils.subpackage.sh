TERMUX_SUBPKG_INCLUDE="bin/"
TERMUX_SUBPKG_DESCRIPTION="Tools using the harfbuzz library"
TERMUX_SUBPKG_DEPENDS="libcairo, fontconfig, liblzma, libpixman, libxml2"
